# Middle East ERP Software Market — Structured Dataset

This dataset is created from publicly available information from the Middle East ERP Software Market report by NextMSC.

## Dataset Contents
- `market_overview.csv`
- `segmentation.csv`
- `metadata.json`
- `README.md`

## Source
https://www.nextmsc.com/report/middle-east-erp-software-market-ic3614

## Disclaimer
This dataset is for educational and research purposes only.
